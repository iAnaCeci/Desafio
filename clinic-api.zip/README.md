# Clinic API

This project is a RESTful API for a clinic management system built with Node.js, Express, TypeScript, PostgreSQL, and TypeORM.

## Features

- Register patients
- Register doctors
- Create appointments between patients and doctors
- List appointments for a specific doctor
- List appointments for a specific patient
- Input validation
- Error handling
- Seed initial data

## Requirements

- Node.js >= 14
- PostgreSQL

## Setup

1. Clone the repository
2. Copy \`.env.example\` to \`.env\` and update variables
3. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
4. Seed initial data:
   \`\`\`bash
   npm run seed
   \`\`\`
5. Start the development server:
   \`\`\`bash
   npm run dev
   \`\`\`
6. Build for production:
   \`\`\`bash
   npm run build
   npm start
   \`\`\`

## Docker

To run with Docker:

\`\`\`bash
docker-compose up --build
\`\`\`
