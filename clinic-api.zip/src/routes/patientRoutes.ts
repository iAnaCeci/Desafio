import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { Patient } from '../entity/Patient';
import { AppDataSource } from '../data-source';

const router = Router();
const repo = AppDataSource.getRepository(Patient);

router.post(
  '/',
  [body('name').notEmpty(), body('email').isEmail()],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    try {
      const patient = repo.create(req.body);
      const result = await repo.save(patient);
      res.status(201).json(result);
    } catch (err) {
      next(err);
    }
  }
);

export default router;
