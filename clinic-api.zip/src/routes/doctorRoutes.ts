import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { Doctor } from '../entity/Doctor';
import { AppDataSource } from '../data-source';

const router = Router();
const repo = AppDataSource.getRepository(Doctor);

router.post(
  '/',
  [body('name').notEmpty(), body('specialty').notEmpty(), body('email').isEmail()],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    try {
      const doctor = repo.create(req.body);
      const result = await repo.save(doctor);
      res.status(201).json(result);
    } catch (err) {
      next(err);
    }
  }
);

export default router;
