import { Router } from 'express';
import { body, validationResult, param } from 'express-validator';
import { Appointment } from '../entity/Appointment';
import { Patient } from '../entity/Patient';
import { Doctor } from '../entity/Doctor';
import { AppDataSource } from '../data-source';

const router = Router();
const repo = AppDataSource.getRepository(Appointment);

router.post(
  '/',
  [
    body('date').isISO8601(),
    body('patientId').isInt(),
    body('doctorId').isInt(),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    try {
      const { date, patientId, doctorId } = req.body;
      const patientRepo = AppDataSource.getRepository(Patient);
      const doctorRepo = AppDataSource.getRepository(Doctor);
      const patient = await patientRepo.findOneBy({ id: patientId });
      const doctor = await doctorRepo.findOneBy({ id: doctorId });
      if (!patient || !doctor) {
        return res.status(404).json({ message: 'Patient or Doctor not found' });
      }
      const appointment = repo.create({ date, patient, patientId, doctor, doctorId });
      const result = await repo.save(appointment);
      res.status(201).json(result);
    } catch (err) {
      next(err);
    }
  }
);

router.get('/doctor/:doctorId', [param('doctorId').isInt()], async (req, res, next) => {
  const { doctorId } = req.params;
  try {
    const appointments = await repo.find({ where: { doctorId: parseInt(doctorId) } });
    res.json(appointments);
  } catch (err) {
    next(err);
  }
});

router.get('/patient/:patientId', [param('patientId').isInt()], async (req, res, next) => {
  const { patientId } = req.params;
  try {
    const appointments = await repo.find({ where: { patientId: parseInt(patientId) } });
    res.json(appointments);
  } catch (err) {
    next(err);
  }
});

export default router;
