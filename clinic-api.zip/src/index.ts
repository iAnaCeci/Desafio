import express from 'express';
import * as dotenv from 'dotenv';
import 'reflect-metadata';
import { AppDataSource } from './data-source';
import patientRoutes from './routes/patientRoutes';
import doctorRoutes from './routes/doctorRoutes';
import appointmentRoutes from './routes/appointmentRoutes';
import { errorHandler } from './middleware/errorHandler';

dotenv.config();

AppDataSource.initialize()
  .then(() => {
    const app = express();
    app.use(express.json());
    app.use('/patients', patientRoutes);
    app.use('/doctors', doctorRoutes);
    app.use('/appointments', appointmentRoutes);
    app.use(errorHandler);

    const port = process.env.PORT || 3000;
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  })
  .catch((error) => console.error('Data Source initialization error:', error));
