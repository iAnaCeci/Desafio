import 'reflect-metadata';
import { AppDataSource } from '../data-source';
import { Patient } from '../entity/Patient';
import { Doctor } from '../entity/Doctor';

async function seed() {
  await AppDataSource.initialize();
  const patientRepo = AppDataSource.getRepository(Patient);
  const doctorRepo = AppDataSource.getRepository(Doctor);

  const patients = [
    { name: 'John Doe', email: 'john@example.com' },
    { name: 'Jane Smith', email: 'jane@example.com' },
  ];

  const doctors = [
    { name: 'Dr. Alice', specialty: 'Cardiology', email: 'alice@example.com' },
    { name: 'Dr. Bob', specialty: 'Dermatology', email: 'bob@example.com' },
  ];

  await patientRepo.save(patients);
  await doctorRepo.save(doctors);

  console.log('Seeding completed');
  process.exit(0);
}

seed();
